plugins {
    id("com.android.application")
}

android {
    namespace = "com.atharventerprises.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.atharventerprises.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    // The Release APK is signed with the CI runner's debug key so it can be
    // installed directly for testing. Configure a private persistent keystore
    // before distributing updates broadly or publishing to Google Play.
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }
}
